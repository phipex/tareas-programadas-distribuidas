package co.com.ies.pruebas.scheduledistributedtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScheduleDistributedTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScheduleDistributedTaskApplication.class, args);
	}

}
