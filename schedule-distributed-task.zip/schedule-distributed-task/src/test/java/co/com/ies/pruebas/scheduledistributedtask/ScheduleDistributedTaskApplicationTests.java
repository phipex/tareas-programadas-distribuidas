package co.com.ies.pruebas.scheduledistributedtask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheduleDistributedTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
